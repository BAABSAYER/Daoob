# App Icon Instructions

The app icon is set to use the logo image without text.

## Generating app icons

To generate app icons, run:

```bash
flutter pub get
flutter pub run flutter_launcher_icons
```

This will create app icons based on the image at assets/images/full_logo.jpg
