package com.example.daoob_mobile;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
