#!/bin/bash
flutter pub get
flutter pub run flutter_launcher_icons
echo "App icons generated successfully!"
